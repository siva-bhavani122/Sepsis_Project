## for  example, a very simple accessor function:
get@PKGNAME@ = function(n) @PKGNAME@[n]

